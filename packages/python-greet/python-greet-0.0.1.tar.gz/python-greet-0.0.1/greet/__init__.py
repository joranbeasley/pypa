def hello(name):
    print("Hello %s"%(name))
